//
//  ViewController.swift
//  WordGuess
//
//  Created by Ponnam,Jagadeesh on 3/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var underscore: UILabel!
    
    @IBOutlet weak var HintLabel: UILabel!
    
    @IBOutlet weak var EnteredText: UITextField!
    
    @IBOutlet weak var CheckButton: UIButton!
    
    
    @IBAction func CheckButtonClicked(_ sender: Any) {
        //Get the text from the text field
        var letter = EnteredText.text!
        //Replace the guessed letter if the letter is part of the word
        letterGuessed = letterGuessed + letter
        var revealword = ""
        for l in name{
            if letterGuessed.contains(l){
                revealword += "\(l)"
            }
            else{
                revealword += "_"
            }
        }
        //Assigning the display label after a guess
        underscore.text = revealword
        EnteredText.text = ""
        
        //If the word is correct enabling play agin button and disabling the check button
        if underscore.text!.contains("_") == false{
            PlayAgainButton.isHidden = false;
            CheckButton.isEnabled = false;
        }
        CheckButton.isEnabled = false
        
    }
    
    @IBAction func PlayAgainButtonClicked(_ sender: Any) {
        //Reset the button to disable initially
        PlayAgainButton.isHidden = true
        //Clear the label
        letterGuessed = ""
        count += 1
        //If count reaches the end of the array then print the conguratulations in status label
        if count == names.count{
            StatusLabel.text = "Conguratulations! You are done with the game!"
        }
    }
    
    @IBOutlet weak var StatusLabel: UILabel!
    
    @IBOutlet weak var PlayAgainButton: UIButton!
    
    var names = [["SWIFT", "Programming Language"], ["Dog", "Animal"], ["Cycle", "Two Wheeler"], ["MACBOOK", "Apple Device"]]
    
    var count = 0;
    var name = ""
    var letterGuessed = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Check button should be disabled.
        CheckButton.isEnabled = false;
        //Get the first word from the array
        name = names[count][0]
        
        underscore.text = ""
        //Populate the display with the underscores. The # of underscores is equal to the # of characters in the word.
        //updateUnderscores();
        
        //Get the first hint from the array
        HintLabel.text = "Hint: "+names[count][1];
        //Clear the status label initially
        StatusLabel.text = ""
        
    }
    


}

