//
//  ViewController.swift
//  sampleprojectApp2
//
//  Created by Ponnam,Jagadeesh on 1/26/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var Course1: UITextField!
    
    @IBOutlet weak var Course2: UITextField!
    
    @IBOutlet weak var DisplayingLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func Evaluate(_ sender: Any) {
    
    //Initially read the course1 name and store in a variable
    var cs1 = Course1.text!
    var cs2 = Course2.text!
    //String interpolation and assign to display label
    DisplayingLabel.text = "\(cs1) - \(cs2)"
  
    }
    
}

