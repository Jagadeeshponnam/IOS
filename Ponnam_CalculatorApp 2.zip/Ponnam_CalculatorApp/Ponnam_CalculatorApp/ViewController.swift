//
//  ViewController.swift
//  Ponnam_CalculatorApp
//
//  Created by Ponnam,Jagadeesh on 2/15/23.
//

import UIKit

class ViewController: UIViewController {
    var op1:Double = -9.99
    var op2:Double = -9.99
    var calculateop:String=""

    @IBOutlet weak var OutputOutlet: UILabel!
    
    @IBAction func ACButton(_ sender: UIButton) {
        OutputOutlet.text=""
        op1 = -9.99
        op2 = -9.99
        
    }
    
    @IBAction func CButton(_ sender: UIButton) {
        var temp=OutputOutlet.text!
        if(!temp.isEmpty){
            temp.removeLast()}
        if(temp.isEmpty){
            op1 = -9.99
            op2 = -9.99
        }
        OutputOutlet.text=temp
    }
    
    @IBAction func PlusorMinusBtn(_ sender: UIButton) {
        if calculateop == "-"{
            calculateop = "+"
        }
        else if calculateop == "+"{
            calculateop = "-"
        }
    }
    
    @IBAction func DivideBtn(_ sender: UIButton) {
        op1=Double(OutputOutlet.text!) ?? 0.0
        OutputOutlet.text=OutputOutlet.text!+"÷"
        calculateop = "÷"
        OutputOutlet.text=""
    }
    
    @IBAction func MultiplyBtn(_ sender: UIButton) {
        op1=Double(OutputOutlet.text!) ?? 0.0
        OutputOutlet.text = "X"
        calculateop = "X"
        OutputOutlet.text = ""
    }
    
    @IBAction func MinusBtn(_ sender: UIButton) {
        op1=Double(OutputOutlet.text!) ?? 0.0
        OutputOutlet.text = "-"
        calculateop = "-"
        OutputOutlet.text = ""
    }
    @IBAction func PlusBtn(_ sender: UIButton) {
        op1=Double(OutputOutlet.text!) ?? 0.0
        OutputOutlet.text = "+"
        calculateop = "+"
        OutputOutlet.text = ""
    }
    
    @IBAction func EqualBtn(_ sender: UIButton) {
        op2=Double(OutputOutlet.text!) ?? 0.0
        if calculateop.contains("+") {
        var Result = op1+op2
            if (Result.truncatingRemainder(dividingBy:1)==0){
                OutputOutlet.text="\(Int(Result))"
            }
            else {
                OutputOutlet.text="\(Result)"}
            }
        else if calculateop.contains("-"){
            var Result=op1-op2
        
        if (Result.truncatingRemainder(dividingBy:1)==0){
            OutputOutlet.text="\(Int(Result))"
        }
        else {
            OutputOutlet.text="\(Result)"}
        }
    else if calculateop.contains("X"){
        var Result=op1*op2
        if (Result.truncatingRemainder(dividingBy:1)==0){
            OutputOutlet.text="\(Int(Result))"
        }
        else {
            OutputOutlet.text="\(Result)"}
        }
    else if calculateop.contains("÷"){
        var Result=op1/op2
        if(op2 == 0){
            OutputOutlet.text = "Not a Number"
        }
        else
        if (Result.truncatingRemainder(dividingBy:1)==0){
            OutputOutlet.text="\(Int(Result))"
        }
        else {
            OutputOutlet.text = "\(round(Result*100000)/100000.0)"}
        }
       if calculateop.contains("%"){
           var Result=op1.truncatingRemainder(dividingBy:op2)
           if (Result.truncatingRemainder(dividingBy:1)==0){
               OutputOutlet.text="\(Int(Result))"
           }
           else {
               OutputOutlet.text = "\(round(Result*100000)/100000.0)"}
           }
    }
    
    @IBAction func PercentageBtn(_ sender: UIButton) {
        op1=Double(OutputOutlet.text!) ?? 0.0
        OutputOutlet.text = "%"
        calculateop = "%"
        OutputOutlet.text = ""
    }
    
    @IBAction func SevenBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"7"
    }
    
    @IBAction func EightBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"8"
    }
    
    @IBAction func NineBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"9"
    }
    
    @IBAction func SixBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"6"
    }
    
    @IBAction func FiveBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"5"
    }
    
    @IBAction func FourBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"4"
    }
    
    @IBAction func ThreeBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"3"
    }
    
    @IBAction func TwoBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"2"
    }
    
    @IBAction func OneBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"1"
    }
    
    @IBAction func ZeroBtn(_ sender: UIButton) {
        OutputOutlet.text=OutputOutlet.text!+"0"
    }
    
    @IBAction func DotBtn(_ sender: UIButton) {
        if(!OutputOutlet.text!.contains(".")){
            OutputOutlet.text=OutputOutlet.text!+"."
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}


