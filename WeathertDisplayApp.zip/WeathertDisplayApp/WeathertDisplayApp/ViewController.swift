//
//  ViewController.swift
//  WeathertDisplayApp
//
//  Created by Ponnam,Jagadeesh on 2/27/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputTemp: UITextField!

    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var outyputtext: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func evaluate(_ sender: Any) {
        var temp = Double(inputTemp.text!)
        if(temp! < 10) {
            imageView.image=UIImage(named:"Cold" )
            outyputtext.text = "It feels like Cold"
        }
        else if (temp! > 20 && temp! <= 30) {
            imageView.image=UIImage(named:"Moderate" )
            outyputtext.text = "It feels like Moderate"
            
        }
        else if(temp! > 30) {
            imageView.image=UIImage(named:"Hot" )
            outyputtext.text = "It feels like Hot"
        }
    }
    
}

