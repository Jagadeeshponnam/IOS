//
//  ViewController.swift
//  MVCDiscountApp
//
//  Created by Ponnam,Jagadeesh on 3/30/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var EnterPrice: UITextField!
    
    
    @IBOutlet weak var EnterDiscount: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    var PriceAfterDiscount = 0.0
    @IBAction func Calcilate(_ sender: Any) {
        // read the text and convert it to double
        var amount = Double(EnterPrice.text!)
        var Disc = Double(EnterDiscount.text!)
        
        print(Disc!)
        PriceAfterDiscount = amount! - (amount!*Disc!/100)
        print(PriceAfterDiscount)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //create a transition
        var transition = segue.identifier
        if (transition == "resultSegue") {
            //Create a destination
            var destination = segue.destination as! ResultViewController
            
            // Assign values to resultviewController
            destination.destinationAmount = EnterPrice.text!
            destination.destinationDiscRate = EnterDiscount.text!
            destination.result = String(PriceAfterDiscount)
        }
    }



}

