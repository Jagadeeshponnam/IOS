//
//  ResultViewController.swift
//  MVCDiscountApp
//
//  Created by Ponnam,Jagadeesh on 3/30/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var EnteredAmount: UILabel!
    
    @IBOutlet weak var EnteredDiscount: UILabel!
    
    @IBOutlet weak var PriceAfterDiscount: UILabel!
    
    //Need variables to store the values.
    var destinationAmount = ""
    var destinationDiscRate = ""
    var result = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        EnteredAmount.text!+=destinationAmount
        EnteredDiscount.text!+=destinationDiscRate
        PriceAfterDiscount.text!+=result
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
