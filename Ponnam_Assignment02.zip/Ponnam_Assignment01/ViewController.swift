//
//  ViewController.swift
//  Ponnam_Assignment01
//
//  Created by Ponnam,Jagadeesh on 1/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var firstNameOutlet: UITextField!
    
    @IBOutlet weak var lastNameOutlet: UITextField!
    @IBOutlet weak var yearOutlet: UITextField!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var initialsLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!

    @IBOutlet weak var DetailsLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SubmitBTN(_ sender: Any) {
        //Reading the input values
        var fName = firstNameOutlet.text!
        var lName = lastNameOutlet.text!
        var dob = yearOutlet.text!
        //Changing the birthyear to integer
        var birthyear = Int (dob) ?? 0
        //Getting the current system year
        var currentYear = Calendar.current.component(.year, from: Date())
        //Performing string interpolation
        DetailsLabel.text = "Details"
        fullNameLabel.text = "Full Name : \(lName) \(fName)"
        initialsLabel.text = "Initials : \(lName.first!.uppercased()) \(fName.first!.uppercased())"
        ageLabel.text = "Age : \(currentYear-birthyear)"
    }
    
    @IBAction func ResetBTN(_ sender: Any) {
        //After clicking the reset button clearing data from input given
        firstNameOutlet.text = ""
        lastNameOutlet.text = ""
        yearOutlet.text = ""
        fullNameLabel.text = ""
        initialsLabel.text = ""
        ageLabel.text = ""
        DetailsLabel.text = ""
    }
    
}

