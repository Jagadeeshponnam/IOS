//
//  ViewController.swift
//  DisplayImageApp
//
//  Created by Ponnam,Jagadeesh on 2/27/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayImage: UIImageView!
    
    @IBOutlet weak var Label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitButton(_ sender: Any) {
        DisplayImage.image = UIImage(named: "JrNTR")
        Label.text = "NTR Family Rocking"
    }
    
}

