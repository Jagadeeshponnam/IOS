//
//  ViewController.swift
//  OwnApp
//
//  Created by Ponnam,Jagadeesh on 1/26/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var SID: UITextField!
    
    
    @IBOutlet weak var PASSWORD: UITextField!
    
    
    @IBOutlet weak var DisplayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func GetIn(_ sender: Any) {
        //Read the course names as given input
        var S = SID.text!
        var P = PASSWORD.text!
        //Assign data to get in
        DisplayLabel.text = "Welcome TO NWMSU , \(S) -- \(P)"
    }
    
    
    
}

