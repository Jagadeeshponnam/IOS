//
//  ViewController.swift
//  VowelCheckerApp
//
//  Created by Ponnam,Jagadeesh on 1/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var outputDisplay: UILabel!
    @IBAction func Checker(_ sender: Any) {
        //Read the text entered in input
        var Tx = inputText.text!
        //Check for vowel in given text
        Tx=Tx.lowercased()
        if (Tx.contains("a") || Tx.contains("e") || Tx.contains("i") || Tx.contains("o") || Tx.contains("u") ){
            //Displaying the label
            outputDisplay.text="The entered text has vowels😄"
        }
        else {
            outputDisplay.text="The entered text has no vowels🙃"
        }
            
    }
    
    
}

