//
//  ViewController.swift
//  DiscountApp
//
//  Created by Ponnam,Jagadeesh on 2/14/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var Enteramt: UITextField!
    
    @IBOutlet weak var Enterdsct: UITextField!
    
    @IBOutlet weak var Display: UILabel!
   
    @IBAction func Calculate(_ sender: Any) {
    
    
    var Enteramt = Double(Enteramt.text!)
    var Enterdsct = Double(Enterdsct.text!)
        var Calculate = Enteramt! - (Enteramt!*(Enterdsct!/100.00))
    
    Display.text = "Price after amount: $\(Calculate)"
    
    }
 
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

